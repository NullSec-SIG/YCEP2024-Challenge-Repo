This directory does not contain any clues on how to solve the
challenge, so it can be safely ignored.