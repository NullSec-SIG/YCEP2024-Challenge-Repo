from Crypto.Util.number import *

flag = r"YCEP24{FAKEFLAG}" # find out what this flag is!

# Generate RSA key pair
p = getPrime(1024)
q = getPrime(1024)
n = p * q
phi = (p - 1) * (q - 1)
e = 65537
d = inverse(e, phi)

encrypted_flag = pow(bytes_to_long(flag.encode()), e, n)


with open("values.txt", "w") as f:
    f.write("p=" + str(p) + "\n")
    f.write("q=" + str(q) + "\n")
    f.write("e=" + str(e) + "\n")
    f.write("c=" + str(encrypted_flag))